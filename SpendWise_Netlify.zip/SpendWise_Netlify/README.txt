SpendWise - Netlify Static Edition

DEPLOY:
1. Open https://app.netlify.com/drop
2. Drag and drop the SpendWise_Netlify.zip file, or extract it and drop the SpendWise_Netlify folder.
3. Open the URL Netlify provides.

IMPORTANT:
This is a static HTML/CSS/JavaScript conversion of the original Flask dashboard, not the original Flask app.
Data is saved in localStorage on one browser/device only. It does not sync across devices and can be lost if browser storage is cleared. No password protection is included.
Use Export Backup regularly and keep backup JSON files safe. Import Backup restores data (replacing existing records).
For reliable multi-device or cloud-backed storage, a database and authentication would be needed.
